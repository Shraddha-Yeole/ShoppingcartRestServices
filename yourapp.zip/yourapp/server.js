var express = require('express'),
  app = express(),
  port = process.env.PORT || 3000;
var redis = require('redis');
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
var redisClient = redis.createClient({host : 'localhost', port : 6379});
var user_id = 30;
redisClient.on('ready',function() {
 console.log("Redis is ready");
});

redisClient.on('error',function() {
 console.log("Error in Redis");
});

app.listen(port);
/*
app.get('/',function(req,res){
	res.send('hello');
});
*/

/*
redisClient.exists(req.body.username,function(err,reply) {
 if(!err) {
  if(reply === 1) {
   console.log("User exists");


  } else {
   console.log("Does't exists");
  }
 }
});*/





app.post('/fail', function(req, res) {

//redisClient.hmset("cart:sayali@gmail.com","R2", "Chipotle", "M1", "VegBowl:6.75:4" ,"M2", "Salad:8.50:1",function(err,reply) {
 //console.log(err);
 console.log("in post of fail");
 //console.log("in post of fail req=",req);
 console.log("in post of fail req.body=",req.body);
 redisClient.exists(req.body.username,function(err,reply) {
 if(!err) {
  if(reply === 1) {
   console.log("User exists",reply);
   redisClient.HGETALL(req.body.username,function(err,userData) {
    if(err){
      res.send(err);
    }
    console.log(userData.menu);
    var str1=userData.menu;
    console.log("str1=",userData.menu);
    var menuData=str1.concat(req.body.menu);
    console.log("menuData=",menuData);
      //Set updated Menu
      redisClient.hmset(req.body.username, "menu",menuData,function(err,reply) {
        if(err){
          res.send(err);
        }
        console.log(reply);
        res.send(reply);
      });
     //res.send(userData);
   });

  } else {
   console.log("Does't exists");
    redisClient.hmset(req.body.username, "menu",req.body.menu,function(err,reply) {
      if(err){
        res.send(err);
      }
      console.log(reply);
      res.send(reply);
    });
  }
 }
});

});

/*
redisClient.hmset("20","restaurant_id","300","restaurant_name","taorigrill","menu_id","20","menu_name","biryani","quantity","2","price","$16",function(err,reply) {
 //console.log(err);
 //console.log(reply);
});

*/

/*
redisClient.hgetall("user_id",function(err,reply) {
 //console.log(err);
 console.log(reply);
});
*/

app.get('/try/:username', function(req, res) {

 //var username = req.params.user;
 console.log("in get of try",req.params.username);
 redisClient.HGETALL(req.params.username,function(err,reply) {
  if(err){
    res.send(err);
  }
   console.log(reply);
   res.send(reply);
});
});

/*
app.get('/second', function(req, res) {

 //var username = req.params.user;
 redisClient.hgetall("20",function(err,reply) {
 console.log(err);
 console.log(reply);
 res.send(reply);
});
});

*/


redisClient.exists('user_id',function(err,reply) {
 if(!err) {
  if(reply === 1) {
   console.log("User exists");
  } else {
   console.log("Does't exists");
  }
 }
});

/*
redisClient.del('user_id',function(err,reply) {
 if(!err) {
  if(reply === 1) {
   console.log("Key is deleted");
  } else {
   console.log("Does't exists");
  }
 }
});
*/
/*
redisClient.hincrby('user_id', 'quantity', '205',function(err,reply){
	console.log(reply);
});
*/

console.log('server started on: ' + port);