var express = require('express'),
  app = express(),
  port = process.env.PORT || 3000;
var redis = require('redis');
var redisClient = redis.createClient({host : 'localhost', port : 6379});

redisClient.on('ready',function() {
 console.log("Redis is ready");
});

redisClient.on('error',function() {
 console.log("Error in Redis");
});

app.listen(port);
/*
app.get('/',function(req,res){
	res.send('hello');
});
*/

redisClient.hmset("user_id","restaurant_id","100","restaurant_name","tandoori","menu_id","10","menu_name","chicken","quantity","2","price","$16",function(err,reply) {
 console.log(err);
 console.log(reply);
});

redisClient.hgetall("user_id",function(err,reply) {
 console.log(err);
 console.log(reply);
});


app.get('/', function(req, res) {

 //var username = req.params.user;
 redisClient.hgetall("user_id",function(err,reply) {
 console.log(err);
 console.log(reply);
 res.send(reply);
});
});


redisClient.exists('user_id',function(err,reply) {
 if(!err) {
  if(reply === 1) {
   console.log("User exists");
  } else {
   console.log("Does't exists");
  }
 }
});

/*
redisClient.del('user_id',function(err,reply) {
 if(!err) {
  if(reply === 1) {
   console.log("Key is deleted");
  } else {
   console.log("Does't exists");
  }
 }
});
*/
/*
redisClient.hincrby('user_id', 'quantity', '205',function(err,reply){
	console.log(reply);
});
*/

console.log('server started on: ' + port);